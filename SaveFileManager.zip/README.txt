mardi 03 novembre 2009
Programme crée par Sarathai
Licence creative commons

Pour envoyer des fichiers sur le serveur, cliquer d'abord sur le bouton ajouter,
puis sélectionnez le dossier ou fichier à ajouter. Répétez cette opération autant de foi que nécessaire.
Puis cliquez sur le bouton envoyer en ayant d'abord rempli les champs de l'adresse ip et du port.

Pour recevoir des fichiers sauvegardés sur le serveur, cliquez sur le bouton recevoir,
puis sélectionnez le ou les fichier(s) voulu(s) dans la liste de gauche, et enfin recliquez
sur le bouton recevoir pour importer les fichiers.

Pour toutes les infos, bien lire le texte qui s'affiche dans le champ de texte en bas.

